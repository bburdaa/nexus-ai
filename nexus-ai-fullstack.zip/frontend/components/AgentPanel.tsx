
export default function AgentPanel() {
  return (
    <div className="p-4 bg-white rounded shadow-md">
      <h2 className="text-xl font-semibold">AI Agent Control Panel</h2>
      <p>Manage your AI agents, assign roles, and monitor responses.</p>
    </div>
  );
}
