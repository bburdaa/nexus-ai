
export default function LogViewer() {
  return (
    <div className="mt-4 bg-black text-green-400 p-3 rounded">
      <p>System Log Output:</p>
      <code>Initializing AI Engine...</code>
    </div>
  );
}
