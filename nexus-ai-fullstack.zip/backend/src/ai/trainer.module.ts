
import { Injectable } from '@nestjs/common';

@Injectable()
export class TrainerModule {
  private memory: Record<string, string> = {};

  learn(context: string, outcome: string): void {
    this.memory[context] = outcome;
  }

  recall(context: string): string {
    return this.memory[context] || 'No data found';
  }
}
