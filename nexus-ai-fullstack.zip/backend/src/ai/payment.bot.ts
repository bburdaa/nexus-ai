
import { Injectable } from '@nestjs/common';

@Injectable()
export class PaymentBot {
  async optimize(transaction: any): Promise<string> {
    if (transaction.amount > 5000) {
      return 'Route through Gateway A';
    }
    return 'Route through Gateway B';
  }
}
