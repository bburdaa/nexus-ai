
import { Injectable } from '@nestjs/common';

@Injectable()
export class FraudScanner {
  analyze(transaction: any): boolean {
    return transaction.velocity > 10 || transaction.riskScore > 80;
  }
}
