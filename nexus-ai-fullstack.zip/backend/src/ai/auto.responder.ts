
import { Injectable } from '@nestjs/common';

@Injectable()
export class AutoResponder {
  async respondTo(message: string): Promise<string> {
    if (message.toLowerCase().includes('help')) {
      return 'How can I assist you with your transaction?';
    }
    return 'Thank you for your message. An agent will respond shortly.';
  }
}
