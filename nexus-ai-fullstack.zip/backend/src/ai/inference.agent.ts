
import { Injectable } from '@nestjs/common';

@Injectable()
export class InferenceAgent {
  async decide(input: string): Promise<string> {
    if (input.includes('fail')) {
      return 'Reroute to Backup Gateway';
    }
    return 'Proceed with Primary Gateway';
  }
}
