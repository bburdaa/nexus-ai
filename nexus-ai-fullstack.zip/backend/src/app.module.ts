
import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { PaymentModule } from './payments/payment.module';
import { AgentModule } from './ai/agent.module';
import { FraudModule } from './fraud/fraud.module';

@Module({
  imports: [AuthModule, PaymentModule, AgentModule, FraudModule],
})
export class AppModule {}
